﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Data.SqlClient;

namespace api_enderecos.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EnderecosController : ControllerBase
    {

        [HttpGet]
        public async Task<Enderecos> Get(int IdEndereco)
        {
            var retorno = new Enderecos();

            try
            {

                retorno.ListaEnderecos = await new BancodeDados().ExecutarProcedure<Endereco>(
                    "SP_SELECIONA_CENDERECO",
                    new System.Data.SqlClient.SqlParameter("@CEID", IdEndereco));
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPost]
        public async Task<RetornoAPI> Post(Endereco modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CERUA", modelo.Rua));
                ParametrosEntrada.Add(new SqlParameter("@CENUMERO", modelo.Número));
                ParametrosEntrada.Add(new SqlParameter("@CECOMPLEMENTO", modelo.Complemento));
                ParametrosEntrada.Add(new SqlParameter("@CEBAIRRO", modelo.Bairro));
                ParametrosEntrada.Add(new SqlParameter("@CECIDADE", modelo.Cidade));
                ParametrosEntrada.Add(new SqlParameter("@CEUF", modelo.Uf));
                ParametrosEntrada.Add(new SqlParameter("@CEPAIS", modelo.País));
                ParametrosEntrada.Add(new SqlParameter("@CELOCALIZACAOGOOGLE", modelo.LocalizacaoGoogle));

                await new BancodeDados().ExecutarProcedure<Endereco>(
                    "SP_INCLUIR_CENDERECO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpDelete]
        public async Task<RetornoAPI> Delete(int IdEndereco)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CEID", IdEndereco));


                await new BancodeDados().ExecutarProcedure<Endereco>(
                    "SP_EXCLUIR_CENDERECO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPut]
        public async Task<RetornoAPI> Put(Endereco modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();

                ParametrosEntrada.Add(new SqlParameter("@CEID", modelo.IdEndereco));
                ParametrosEntrada.Add(new SqlParameter("@CERUA", modelo.Rua));
                ParametrosEntrada.Add(new SqlParameter("@CENUMERO", modelo.Número));
                ParametrosEntrada.Add(new SqlParameter("@CECOMPLEMENTO", modelo.Complemento));
                ParametrosEntrada.Add(new SqlParameter("@CEBAIRRO", modelo.Bairro));
                ParametrosEntrada.Add(new SqlParameter("@CECIDADE", modelo.Cidade));
                ParametrosEntrada.Add(new SqlParameter("@CEUF", modelo.Uf));
                ParametrosEntrada.Add(new SqlParameter("@CEPAIS", modelo.País));
                ParametrosEntrada.Add(new SqlParameter("@CELOCALIZACAOGOOGLE", modelo.LocalizacaoGoogle));

                await new BancodeDados().ExecutarProcedure<Endereco>(
                    "SP_ALTERA_CENDERECO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }
    }
}
