using System;
using System.Data;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Collections.Generic;

namespace api_enderecos
{
    public class Enderecos : RetornoAPI
    {
        public List<Endereco> ListaEnderecos { get; set; }
    }


    public class Endereco
    {

        [Coluna("CEID")]
        public int IdEndereco { get; set; }

        [Coluna("CERUA")]
        public string Rua { get; set; }

        [Coluna("CENUMERO")]
        public string N�mero { get; set; }

        [Coluna("CECOMPLEMENTO")]
        public string Complemento { get; set; }

        [Coluna("CEBAIRRO")]
        public string Bairro { get; set; }

        [Coluna("CECIDADE")]
        public string Cidade { get; set; }


        [Coluna("CEUF")]
        public string Uf { get; set; }


        [Coluna("CEPAIS")]
        public string Pa�s { get; set; }


        [Coluna("CELOCALIZACAOGOOGLE")]
        public string LocalizacaoGoogle { get; set; }
    }

}

