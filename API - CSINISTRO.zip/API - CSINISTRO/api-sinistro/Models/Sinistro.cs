using System;
using System.Data;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Collections.Generic;

namespace api_sinistros
{
    public class Sinistros : RetornoAPI
    {
        public List<Sinistro> ListaSinistros { get; set; }
    }


    public class Sinistro
    {

        [Coluna("CSID")]
        public int IdSinistro { get; set; }

        [Coluna("CSPLACAVEICULO")]
        public string PlacaVeiculo { get; set; }

        [Coluna("CSIDSEGURO")]
        public int IdSeguro { get; set; }

        [Coluna("CSDESCRICAO")]
        public string Descricao { get; set; }

    }

}

