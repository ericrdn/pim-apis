﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Data.SqlClient;

namespace api_sinistros.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SinistrosController : ControllerBase
    {

        [HttpGet]
        public async Task<Sinistros> Get(int IdSinistro)
        {
            var retorno = new Sinistros();

            try
            {

                retorno.ListaSinistros = await new BancodeDados().ExecutarProcedure<Sinistro>(
                    "SP_SELECIONAR_CSINISTRO",
                    new System.Data.SqlClient.SqlParameter("@CSID", IdSinistro));
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPost]
        public async Task<RetornoAPI> Post(Sinistro modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CSPLACAVEICULO", modelo.PlacaVeiculo));
                ParametrosEntrada.Add(new SqlParameter("@CSIDSEGURO", modelo.IdSeguro));
                ParametrosEntrada.Add(new SqlParameter("@CSDESCRICAO", modelo.Descricao));

                await new BancodeDados().ExecutarProcedure<Sinistro>(
                    "SP_INCLUIR_CSINISTRO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpDelete]
        public async Task<RetornoAPI> Delete(int IdSinistro)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CSID", IdSinistro));


                await new BancodeDados().ExecutarProcedure<Sinistro>(
                    "SP_EXCLUIR_CSINISTRO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPut]
        public async Task<RetornoAPI> Put(Sinistro modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();

                ParametrosEntrada.Add(new SqlParameter("@CSID", modelo.IdSinistro));
                ParametrosEntrada.Add(new SqlParameter("@CSPLACAVEICULO", modelo.PlacaVeiculo));
                ParametrosEntrada.Add(new SqlParameter("@CSIDSEGURO", modelo.IdSeguro));
                ParametrosEntrada.Add(new SqlParameter("@CSDESCRICAO", modelo.Descricao));

                await new BancodeDados().ExecutarProcedure<Sinistro>(
                    "SP_ALTERAR_CSINISTRO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }
    }
}
