using System;
using System.Data;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Collections.Generic;

namespace api_seguros
{
    public class Seguros : RetornoAPI
    {
        public List<Seguro> ListaSeguros { get; set; }
    }


    public class Seguro
    {

        [Coluna("CCID")]
        public int IdSeguro { get; set; }

        [Coluna("CCPLACAVEICULO")]
        public string PlacaVeiculo { get; set; }

        [Coluna("CCSEGURADORA")]
        public string Seguradora { get; set; }

        [Coluna("CCCONTRATOLOCACAO")]
        public string ContratoLocacao { get; set; }

        [Coluna("CCDTINIVIGENCIA")]
        public DateTime InicioVigencia { get; set; }


        [Coluna("CCDTFIMVIGENCIA")]
        public DateTime FimVigencia { get; set; }


        [Coluna("CCVALORSEGURO")]
        public float ValorSeguro { get; set; }
    }

}

