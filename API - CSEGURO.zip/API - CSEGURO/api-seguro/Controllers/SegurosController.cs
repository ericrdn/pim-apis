﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Funcoes.BancodeDados;
using Funcoes.API;
using System.Data.SqlClient;

namespace api_seguros.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SegurosController : ControllerBase
    {

        [HttpGet]
        public async Task<Seguros> Get(int IdSeguro)
        {
            var retorno = new Seguros();

            try
            {

                retorno.ListaSeguros = await new BancodeDados().ExecutarProcedure<Seguro>(
                    "SP_SELECIONAR_CSEGURO",
                    new System.Data.SqlClient.SqlParameter("@CCID", IdSeguro));
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPost]
        public async Task<RetornoAPI> Post(Seguro modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CCPLACAVEICULO", modelo.PlacaVeiculo));
                ParametrosEntrada.Add(new SqlParameter("@CCSEGURADORA", modelo.Seguradora));
                ParametrosEntrada.Add(new SqlParameter("@CCCONTRATOLOCACAO", modelo.ContratoLocacao));
                ParametrosEntrada.Add(new SqlParameter("@CCDTINIVIGENCIA", modelo.InicioVigencia));
                ParametrosEntrada.Add(new SqlParameter("@CCDTFIMVIGENCIA", modelo.FimVigencia));
                ParametrosEntrada.Add(new SqlParameter("@CCVALORSEGURO", modelo.ValorSeguro));

                await new BancodeDados().ExecutarProcedure<Seguro>(
                    "SP_INCLUIR_CSEGURO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpDelete]
        public async Task<RetornoAPI> Delete(int IdSeguro)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();
                ParametrosEntrada.Add(new SqlParameter("@CCID", IdSeguro));


                await new BancodeDados().ExecutarProcedure<Seguro>(
                    "SP_EXCLUIR_CSEGURO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }

        [HttpPut]
        public async Task<RetornoAPI> Put(Seguro modelo)
        {
            var retorno = new RetornoAPI();
            try
            {
                List<SqlParameter> ParametrosEntrada = new List<SqlParameter>();

                ParametrosEntrada.Add(new SqlParameter("@CCID", modelo.IdSeguro));
                ParametrosEntrada.Add(new SqlParameter("@CCPLACAVEICULO", modelo.PlacaVeiculo));
                ParametrosEntrada.Add(new SqlParameter("@CCSEGURADORA", modelo.Seguradora));
                ParametrosEntrada.Add(new SqlParameter("@CCCONTRATOLOCACAO", modelo.ContratoLocacao));
                ParametrosEntrada.Add(new SqlParameter("@CCDTINIVIGENCIA", modelo.InicioVigencia));
                ParametrosEntrada.Add(new SqlParameter("@CCDTFIMVIGENCIA", modelo.FimVigencia));
                ParametrosEntrada.Add(new SqlParameter("@CCVALORSEGURO", modelo.ValorSeguro));

                await new BancodeDados().ExecutarProcedure<Seguro>(
                    "SP_ALTERAR_CSEGURO", ParametrosEntrada.ToArray());
            }
            catch (Exception E)
            {
                retorno.StatusReq = Status.Erro;
                retorno.MensagemErro = E.Message;
            }

            return retorno;
        }
    }
}
